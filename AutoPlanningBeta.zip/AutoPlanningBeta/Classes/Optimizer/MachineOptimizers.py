import sys
sys.path.append("\\\Client\F$\SHARING\Radiation Oncology Physics\RaystationScriptingPROD")
sys.path.append("F:\SHARING\Radiation Oncology Physics\RaystationScriptingPROD")

from AutoPlanningBeta.Classes.Optimizer.OptimizerBase import OptimizerBase

class TrueBeamOptimizer(OptimizerBase):
    
    _defaults = {**OptimizerBase._defaults,
                 "gantrySpacing": 2.0
                 }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        
    
    def setOptimizationParameters(self):
        super().setOptimizationParameters()
        #Makes the VMAT gantry sampling = 2.0deg
        for idx, b in enumerate(self.bs.Beams):
            try:
                self.plan.PlanOptimizations[0].OptimizationParameters.TreatmentSetupSettings[0].BeamSettings[idx].ArcConversionPropertiesPerBeam.EditArcBasedBeamOptimizationSettings(CreateDualArcs=False, 
                                                                                                                                                                                  FinalGantrySpacing=self.gantrySpacing, 
                                                                                                                                                                                  MaxArcDeliveryTime=90, 
                                                                                                                                                                                  BurstGantrySpacing=None, 
                                                                                                                                                                                  MaxArcMU=None)
            except:
                pass
        return
        
#testing

class RadixactOptimizer(OptimizerBase):
    
    _defaults = {}
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
    def setOptimizationParameters(self):
        super().setOptimizationParameters()
        pass


if __name__=="__main__":
    a = TrueBeamOptimizer(clinicalGoalTemplate="KS Script CG Load Test", optimizationTemplate = "KS Script Opt Load Test")