from connect import *

pd = get_current("PatientDB")

tmp = pd.QueryPatientInfo(Filter= {'Physician': 'JH', 'Gender': 'Female'}, UseIndexService =True)

print(tmp[0])